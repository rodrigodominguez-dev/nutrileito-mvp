
create type public.app_role as enum ('admin','enfermagem','nutricao','cozinha','entrega');

create table public.profiles (
  id uuid primary key,
  nome text not null default '',
  email text,
  created_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  role app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.user_roles where user_id = _user_id and role = _role) $$;

create or replace function public.has_any_role(_user_id uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.user_roles where user_id = _user_id) $$;

create policy "own or admin read profiles" on public.profiles for select to authenticated
  using (id = auth.uid() or public.has_any_role(auth.uid()));
create policy "own profile insert" on public.profiles for insert to authenticated with check (id = auth.uid());
create policy "own profile update" on public.profiles for update to authenticated using (id = auth.uid());

create policy "read own roles or admin" on public.user_roles for select to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));

-- settings
create table public.app_settings (
  id int primary key default 1 check (id = 1),
  min_delivery_minutes int not null default 40 check (min_delivery_minutes between 0 and 240),
  updated_at timestamptz not null default now()
);
insert into public.app_settings (id) values (1);
grant select, update on public.app_settings to authenticated;
grant all on public.app_settings to service_role;
alter table public.app_settings enable row level security;
create policy "staff read settings" on public.app_settings for select to authenticated using (public.has_any_role(auth.uid()));
create policy "admin update settings" on public.app_settings for update to authenticated using (public.has_role(auth.uid(),'admin'));

-- patients
create table public.patients (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  leito text not null,
  unidade text not null,
  status text not null default 'Internado',
  diet_info_demo text,
  restrictions_demo text,
  created_at timestamptz not null default now()
);
grant select on public.patients to authenticated;
grant all on public.patients to service_role;
alter table public.patients enable row level security;
create policy "staff read patients" on public.patients for select to authenticated using (public.has_any_role(auth.uid()));

create sequence public.meal_request_number_seq start 120;
create table public.meal_requests (
  id uuid primary key default gen_random_uuid(),
  number int not null default nextval('public.meal_request_number_seq'),
  patient_id uuid not null references public.patients(id) on delete cascade,
  meal_type text not null,
  patient_request text not null,
  nursing_notes text,
  approved_meal text,
  nutrition_notes text,
  status text not null default 'AGUARDANDO_NUTRICAO',
  returned_to text,
  return_reason text,
  created_by uuid,
  created_by_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  minimum_delivery_time timestamptz not null,
  delivered_at timestamptz
);
grant select on public.meal_requests to authenticated;
grant all on public.meal_requests to service_role;
alter table public.meal_requests enable row level security;
create policy "staff read requests" on public.meal_requests for select to authenticated using (public.has_any_role(auth.uid()));

create table public.nutrition_reviews (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null references public.meal_requests(id) on delete cascade,
  reviewer_id uuid, reviewer_name text,
  decision text not null, approved_meal text, notes text,
  created_at timestamptz not null default now()
);
create table public.kitchen_actions (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null references public.meal_requests(id) on delete cascade,
  user_id uuid, user_name text, action text not null, notes text,
  created_at timestamptz not null default now()
);
create table public.delivery_records (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null references public.meal_requests(id) on delete cascade,
  user_id uuid, user_name text, delivered_at timestamptz not null default now(), notes text
);
create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  request_id uuid references public.meal_requests(id) on delete cascade,
  user_id uuid, actor_name text, actor_role text,
  action text not null, old_status text, new_status text, notes text,
  created_at timestamptz not null default now()
);
create table public.ai_logs (
  id uuid primary key default gen_random_uuid(),
  agent text not null, request_id uuid, user_id uuid, interaction text,
  created_at timestamptz not null default now()
);
grant select on public.nutrition_reviews, public.kitchen_actions, public.delivery_records, public.audit_logs to authenticated;
grant select, insert on public.ai_logs to authenticated;
grant all on public.nutrition_reviews, public.kitchen_actions, public.delivery_records, public.audit_logs, public.ai_logs to service_role;
alter table public.nutrition_reviews enable row level security;
alter table public.kitchen_actions enable row level security;
alter table public.delivery_records enable row level security;
alter table public.audit_logs enable row level security;
alter table public.ai_logs enable row level security;
create policy "staff read" on public.nutrition_reviews for select to authenticated using (public.has_any_role(auth.uid()));
create policy "staff read" on public.kitchen_actions for select to authenticated using (public.has_any_role(auth.uid()));
create policy "staff read" on public.delivery_records for select to authenticated using (public.has_any_role(auth.uid()));
create policy "staff read" on public.audit_logs for select to authenticated using (public.has_any_role(auth.uid()));
create policy "admin read ai" on public.ai_logs for select to authenticated using (public.has_role(auth.uid(),'admin'));
create policy "staff insert ai" on public.ai_logs for insert to authenticated with check (user_id = auth.uid() and public.has_any_role(auth.uid()));

-- leads
create table public.leads (
  id uuid primary key default gen_random_uuid(),
  nome text not null check (char_length(nome) between 2 and 100),
  instituicao text not null check (char_length(instituicao) between 2 and 150),
  cargo text not null check (char_length(cargo) between 2 and 100),
  email text not null check (char_length(email) between 5 and 255),
  whatsapp text not null check (char_length(whatsapp) between 8 and 25),
  leitos int check (leitos between 1 and 100000),
  fluxo_atual text check (char_length(fluxo_atual) <= 1500),
  dificuldade text check (char_length(dificuldade) <= 1500),
  status text not null default 'novo',
  notas text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant insert on public.leads to anon, authenticated;
grant select, update on public.leads to authenticated;
grant all on public.leads to service_role;
alter table public.leads enable row level security;
create policy "anyone submit lead" on public.leads for insert to anon, authenticated with check (status = 'novo');
create policy "admin read leads" on public.leads for select to authenticated using (public.has_role(auth.uid(),'admin'));
create policy "admin update leads" on public.leads for update to authenticated using (public.has_role(auth.uid(),'admin'));

create table public.clients (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid unique references public.leads(id) on delete set null,
  instituicao text not null, contato_nome text, cargo text, email text, whatsapp text, leitos int,
  fase text not null default 'Teste',
  created_at timestamptz not null default now()
);
grant select on public.clients to authenticated;
grant all on public.clients to service_role;
alter table public.clients enable row level security;
create policy "admin read clients" on public.clients for select to authenticated using (public.has_role(auth.uid(),'admin'));

-- bootstrap: profile + first user gets all roles
create or replace function public.bootstrap_me()
returns void language plpgsql security definer set search_path = public as $$
declare _uid uuid := auth.uid(); _email text; _nome text;
begin
  if _uid is null then raise exception 'Não autenticado'; end if;
  select email, coalesce(raw_user_meta_data->>'nome', split_part(email,'@',1)) into _email, _nome from auth.users where id = _uid;
  insert into public.profiles (id, nome, email) values (_uid, _nome, _email) on conflict (id) do nothing;
  if not exists (select 1 from public.user_roles where role = 'admin') then
    insert into public.user_roles (user_id, role)
      select _uid, r from unnest(enum_range(null::app_role)) r on conflict do nothing;
  end if;
end $$;
grant execute on function public.bootstrap_me() to authenticated;

create or replace function public.admin_set_role(_user_id uuid, _role app_role, _grant boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_role(auth.uid(),'admin') then raise exception 'Apenas administradores'; end if;
  if _grant then insert into public.user_roles(user_id, role) values (_user_id, _role) on conflict do nothing;
  else
    if _user_id = auth.uid() and _role = 'admin' then raise exception 'Você não pode remover seu próprio perfil de administrador'; end if;
    delete from public.user_roles where user_id = _user_id and role = _role;
  end if;
end $$;
grant execute on function public.admin_set_role(uuid, app_role, boolean) to authenticated;

create or replace function public.admin_list_users()
returns table (id uuid, nome text, email text, roles text[]) language sql stable security definer set search_path = public as $$
  select p.id, p.nome, p.email, coalesce(array_agg(r.role::text) filter (where r.role is not null), '{}')
  from public.profiles p left join public.user_roles r on r.user_id = p.id
  where public.has_role(auth.uid(),'admin')
  group by p.id order by p.created_at
$$;
grant execute on function public.admin_list_users() to authenticated;

-- create request
create or replace function public.create_meal_request(_patient_id uuid, _meal_type text, _patient_request text, _nursing_notes text)
returns uuid language plpgsql security definer set search_path = public as $$
declare _id uuid; _mins int; _name text;
begin
  if not public.has_role(auth.uid(),'enfermagem') then raise exception 'Apenas a Enfermagem pode criar pedidos'; end if;
  if _patient_id is null or not exists (select 1 from public.patients where id = _patient_id) then raise exception 'Paciente inválido'; end if;
  if _meal_type not in ('Café da manhã','Lanche da manhã','Almoço','Lanche da tarde','Jantar','Ceia','Refeição extraordinária') then raise exception 'Tipo de refeição inválido'; end if;
  if coalesce(trim(_patient_request),'') = '' or char_length(_patient_request) > 1000 then raise exception 'Solicitação do paciente é obrigatória (até 1000 caracteres)'; end if;
  if char_length(coalesce(_nursing_notes,'')) > 1000 then raise exception 'Observação muito longa'; end if;
  select min_delivery_minutes into _mins from public.app_settings where id = 1;
  select nome into _name from public.profiles where id = auth.uid();
  insert into public.meal_requests (patient_id, meal_type, patient_request, nursing_notes, created_by, created_by_name, minimum_delivery_time)
    values (_patient_id, _meal_type, trim(_patient_request), nullif(trim(_nursing_notes),''), auth.uid(), _name, now() + make_interval(mins => _mins))
    returning id into _id;
  insert into public.audit_logs (request_id, user_id, actor_name, actor_role, action, old_status, new_status, notes)
    values (_id, auth.uid(), _name, 'enfermagem', 'Pedido criado pela Enfermagem', null, 'AGUARDANDO_NUTRICAO', null);
  return _id;
end $$;
grant execute on function public.create_meal_request(uuid, text, text, text) to authenticated;

-- transitions
create or replace function public.transition_request(_id uuid, _action text, _notes text default null, _approved_meal text default null, _request_text text default null)
returns text language plpgsql security definer set search_path = public as $$
declare r public.meal_requests; _role app_role; _from text[]; _to text; _label text; _name text; _uid uuid := auth.uid();
begin
  select * into r from public.meal_requests where id = _id for update;
  if not found then raise exception 'Pedido não encontrado'; end if;
  _notes := nullif(trim(coalesce(_notes,'')),'');
  if char_length(coalesce(_notes,'')) > 1000 or char_length(coalesce(_approved_meal,'')) > 1500 then raise exception 'Texto muito longo'; end if;

  case _action
    when 'iniciar_avaliacao' then _role:='nutricao'; _from:=array['AGUARDANDO_NUTRICAO']; _to:='EM_AVALIACAO_NUTRICAO'; _label:='Nutrição iniciou avaliação';
    when 'liberar_cozinha' then _role:='nutricao'; _from:=array['AGUARDANDO_NUTRICAO','EM_AVALIACAO_NUTRICAO']; _to:='LIBERADO_PARA_COZINHA'; _label:='Liberado pela Nutrição para a Cozinha';
    when 'solicitar_ajuste' then _role:='nutricao'; _from:=array['AGUARDANDO_NUTRICAO','EM_AVALIACAO_NUTRICAO']; _to:='DEVOLVIDO_PARA_CORRECAO'; _label:='Nutrição solicitou ajuste à Enfermagem';
    when 'nao_liberar' then _role:='nutricao'; _from:=array['AGUARDANDO_NUTRICAO','EM_AVALIACAO_NUTRICAO']; _to:='CANCELADO'; _label:='Nutrição não liberou o pedido';
    when 'reenviar_nutricao' then _role:='enfermagem'; _from:=array['DEVOLVIDO_PARA_CORRECAO']; _to:='AGUARDANDO_NUTRICAO'; _label:='Enfermagem corrigiu e reenviou à Nutrição';
    when 'iniciar_preparo' then _role:='cozinha'; _from:=array['LIBERADO_PARA_COZINHA','DEVOLVIDO_PARA_CORRECAO']; _to:='EM_PREPARO'; _label:='Cozinha iniciou preparo';
    when 'marcar_pronto' then _role:='cozinha'; _from:=array['EM_PREPARO']; _to:='AGUARDANDO_CONFERENCIA_NUTRICAO'; _label:='Cozinha marcou como pronto';
    when 'cozinha_devolver' then _role:='cozinha'; _from:=array['LIBERADO_PARA_COZINHA','EM_PREPARO']; _to:='DEVOLVIDO_PARA_CORRECAO'; _label:='Cozinha devolveu à Nutrição para correção';
    when 'reliberar_cozinha' then _role:='nutricao'; _from:=array['DEVOLVIDO_PARA_CORRECAO']; _to:='LIBERADO_PARA_COZINHA'; _label:='Nutrição corrigiu e liberou novamente';
    when 'liberar_entrega' then _role:='nutricao'; _from:=array['AGUARDANDO_CONFERENCIA_NUTRICAO']; _to:='LIBERADO_PARA_ENTREGA'; _label:='Conferência final aprovada — liberado para entrega';
    when 'devolver_cozinha' then _role:='nutricao'; _from:=array['AGUARDANDO_CONFERENCIA_NUTRICAO']; _to:='DEVOLVIDO_PARA_CORRECAO'; _label:='Conferência: devolvido à Cozinha';
    when 'confirmar_entrega' then _role:='entrega'; _from:=array['LIBERADO_PARA_ENTREGA']; _to:='ENTREGUE'; _label:='Entregue no leito';
    when 'cancelar' then _role:='admin'; _from:=array['AGUARDANDO_NUTRICAO','EM_AVALIACAO_NUTRICAO','LIBERADO_PARA_COZINHA','EM_PREPARO','AGUARDANDO_CONFERENCIA_NUTRICAO','DEVOLVIDO_PARA_CORRECAO','LIBERADO_PARA_ENTREGA']; _to:='CANCELADO'; _label:='Pedido cancelado pelo Administrador';
    else raise exception 'Ação inválida';
  end case;

  if not public.has_role(_uid, _role) then raise exception 'Seu perfil não permite esta ação'; end if;
  if not (r.status = any(_from)) then raise exception 'Transição inválida a partir do status %', r.status; end if;

  -- returned_to routing
  if r.status = 'DEVOLVIDO_PARA_CORRECAO' then
    if _action = 'reenviar_nutricao' and r.returned_to <> 'enfermagem' then raise exception 'Este pedido não foi devolvido à Enfermagem'; end if;
    if _action = 'iniciar_preparo' and r.returned_to <> 'cozinha' then raise exception 'Este pedido não foi devolvido à Cozinha'; end if;
    if _action = 'reliberar_cozinha' and r.returned_to <> 'nutricao' then raise exception 'Este pedido não foi devolvido à Nutrição'; end if;
  end if;
  if _action in ('solicitar_ajuste','nao_liberar','cozinha_devolver','devolver_cozinha','cancelar') and _notes is null then
    raise exception 'Informe o motivo';
  end if;
  if _action in ('liberar_cozinha','reliberar_cozinha') and coalesce(trim(_approved_meal),'') = '' and coalesce(r.approved_meal,'') = '' then
    raise exception 'Defina a refeição autorizada';
  end if;
  if _action = 'confirmar_entrega' and now() < r.minimum_delivery_time then
    raise exception 'Tempo mínimo ainda não atingido. Entrega disponível a partir de %', to_char(r.minimum_delivery_time at time zone 'America/Sao_Paulo','HH24:MI');
  end if;
  if _action = 'reenviar_nutricao' and _request_text is not null and (trim(_request_text) = '' or char_length(_request_text) > 1000) then
    raise exception 'Solicitação inválida';
  end if;

  select nome into _name from public.profiles where id = _uid;

  update public.meal_requests set
    status = _to, updated_at = now(),
    returned_to = case _action when 'solicitar_ajuste' then 'enfermagem' when 'cozinha_devolver' then 'nutricao' when 'devolver_cozinha' then 'cozinha' else null end,
    return_reason = case when _action in ('solicitar_ajuste','cozinha_devolver','devolver_cozinha','nao_liberar','cancelar') then _notes else null end,
    approved_meal = case when _action in ('liberar_cozinha','reliberar_cozinha') and coalesce(trim(_approved_meal),'') <> '' then trim(_approved_meal) else approved_meal end,
    nutrition_notes = case when _action in ('liberar_cozinha','reliberar_cozinha') then coalesce(_notes, nutrition_notes) else nutrition_notes end,
    patient_request = case when _action = 'reenviar_nutricao' and _request_text is not null then trim(_request_text) else patient_request end,
    delivered_at = case when _action = 'confirmar_entrega' then now() else delivered_at end
  where id = _id;

  if _role = 'nutricao' then
    insert into public.nutrition_reviews (request_id, reviewer_id, reviewer_name, decision, approved_meal, notes)
    values (_id, _uid, _name, _action, _approved_meal, _notes);
  elsif _role = 'cozinha' then
    insert into public.kitchen_actions (request_id, user_id, user_name, action, notes) values (_id, _uid, _name, _action, _notes);
  elsif _action = 'confirmar_entrega' then
    insert into public.delivery_records (request_id, user_id, user_name, notes) values (_id, _uid, _name, _notes);
  end if;

  insert into public.audit_logs (request_id, user_id, actor_name, actor_role, action, old_status, new_status, notes)
    values (_id, _uid, _name, _role::text, _label, r.status, _to, _notes);
  return _to;
end $$;
grant execute on function public.transition_request(uuid, text, text, text, text) to authenticated;

-- leads admin
create or replace function public.update_lead_status(_id uuid, _status text, _notas text default null)
returns void language plpgsql security definer set search_path = public as $$
declare l public.leads;
begin
  if not public.has_role(auth.uid(),'admin') then raise exception 'Apenas administradores'; end if;
  if _status not in ('novo','em_contato','demonstracao_agendada','em_avaliacao','convertido','nao_convertido') then raise exception 'Status inválido'; end if;
  update public.leads set status = _status, notas = coalesce(_notas, notas), updated_at = now() where id = _id returning * into l;
  if not found then raise exception 'Lead não encontrado'; end if;
  if _status = 'convertido' then
    insert into public.clients (lead_id, instituicao, contato_nome, cargo, email, whatsapp, leitos)
    values (l.id, l.instituicao, l.nome, l.cargo, l.email, l.whatsapp, l.leitos) on conflict (lead_id) do nothing;
  end if;
end $$;
grant execute on function public.update_lead_status(uuid, text, text) to authenticated;

create or replace function public.update_min_delivery(_mins int)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_role(auth.uid(),'admin') then raise exception 'Apenas administradores'; end if;
  if _mins < 0 or _mins > 240 then raise exception 'Valor inválido'; end if;
  update public.app_settings set min_delivery_minutes = _mins, updated_at = now() where id = 1;
end $$;
grant execute on function public.update_min_delivery(int) to authenticated;

-- demo seed
create or replace function public.seed_demo_data()
returns void language plpgsql security definer set search_path = public as $$
declare
  pids uuid[]; rid uuid; i int; k int; s int; age int; t0 timestamptz;
  names text[] := array['João da Silva','Maria Oliveira','Carlos Santos','Ana Pereira','Pedro Almeida','Luiza Ferreira','Roberto Lima','Fernanda Costa','Marcos Rocha','Beatriz Souza'];
  diets text[] := array['Dieta geral','Dieta hipossódica','Dieta para diabéticos','Dieta pastosa','Dieta branda','Dieta geral','Dieta hipossódica','Dieta leve','Dieta para diabéticos','Dieta geral'];
  restr text[] := array['Sem restrições registradas','Restrição de sódio','Restrição de açúcar','Evitar alimentos sólidos','Restrição de fritura','Alergia registrada: amendoim','Restrição de sódio','Sem lactose','Restrição de açúcar','Sem restrições registradas'];
  units text[] := array['Clínica Médica','Clínica Médica','Clínica Médica','Cardiologia','Cirúrgica','Pediatria','Cardiologia','Clínica Médica','Endocrinologia','Cirúrgica'];
  meals text[] := array['Almoço','Almoço','Lanche da tarde','Jantar','Almoço','Café da manhã','Almoço','Lanche da tarde','Jantar','Almoço'];
  reqs text[] := array['Arroz, feijão, frango grelhado e suco.','Sopa de legumes e pão.','Fruta e iogurte.','Purê de batata e carne moída.','Macarrão com molho e salada.','Pão com manteiga, café com leite.','Peixe grelhado, arroz e legumes.','Biscoito e chá.','Omelete e salada.','Arroz, feijão, bife e refrigerante.'];
  steps int[] := array[1,1,1,2,2,3,3,4,4,4,5,5,-1,-1,6,6,7,7,7,7];
  ages int[] := array[3,8,15,9,12,14,18,20,25,28,33,36,38,41,36,48,90,150,210,300];
  offs int[] := array[0,6,10,13,32,35,42];
  st text[] := array['AGUARDANDO_NUTRICAO','EM_AVALIACAO_NUTRICAO','LIBERADO_PARA_COZINHA','EM_PREPARO','AGUARDANDO_CONFERENCIA_NUTRICAO','LIBERADO_PARA_ENTREGA','ENTREGUE'];
  lbl text[] := array['Pedido criado pela Enfermagem','Nutrição iniciou avaliação','Liberado pela Nutrição para a Cozinha','Cozinha iniciou preparo','Cozinha marcou como pronto','Conferência final aprovada — liberado para entrega','Entregue no leito'];
  actor text[] := array['Enf. Ana Costa (demo)','Nutr. Maria Lima (demo)','Nutr. Maria Lima (demo)','Cozinha João Reis (demo)','Cozinha João Reis (demo)','Nutr. Maria Lima (demo)','Entrega Paulo Dias (demo)'];
  roles text[] := array['enfermagem','nutricao','nutricao','cozinha','cozinha','nutricao','entrega'];
  final text; meal text; pidx int;
begin
  delete from public.meal_requests;
  delete from public.patients;
  for i in 1..10 loop
    insert into public.patients (nome, leito, unidade, diet_info_demo, restrictions_demo)
    values (names[i], (202 + i)::text, units[i], diets[i], restr[i]);
  end loop;
  select array_agg(id order by leito) into pids from public.patients;

  for i in 1..20 loop
    s := steps[i]; age := ages[i]; pidx := ((i - 1) % 10) + 1;
    k := case when s = -1 then 5 else s end;
    t0 := now() - make_interval(mins => age);
    meal := case when k >= 3 then 'Refeição autorizada: ' || reqs[pidx] || ' Adequada à ' || lower(diets[pidx]) || '.' else null end;
    final := case when s = -1 then 'DEVOLVIDO_PARA_CORRECAO' else st[k] end;
    insert into public.meal_requests (patient_id, meal_type, patient_request, nursing_notes, approved_meal, status, returned_to, return_reason,
      created_by_name, created_at, updated_at, minimum_delivery_time, delivered_at)
    values (pids[pidx], meals[pidx], reqs[pidx], case when i % 3 = 0 then 'Paciente com apetite reduzido.' else null end, meal, final,
      case when s = -1 then 'cozinha' end, case when s = -1 then 'Preparação precisa ser corrigida conforme observação registrada.' end,
      actor[1], t0, now(), t0 + interval '40 minutes', case when k = 7 then t0 + interval '42 minutes' end)
    returning id into rid;
    for j in 1..k loop
      insert into public.audit_logs (request_id, actor_name, actor_role, action, old_status, new_status, created_at)
      values (rid, actor[j], roles[j], lbl[j], case when j = 1 then null else st[j-1] end, st[j], t0 + make_interval(mins => offs[j]));
      if j = 3 then insert into public.nutrition_reviews (request_id, reviewer_name, decision, approved_meal, created_at) values (rid, actor[j], 'liberar_cozinha', meal, t0 + make_interval(mins => offs[j])); end if;
      if j in (4,5) then insert into public.kitchen_actions (request_id, user_name, action, created_at) values (rid, actor[j], case j when 4 then 'iniciar_preparo' else 'marcar_pronto' end, t0 + make_interval(mins => offs[j])); end if;
      if j = 7 then insert into public.delivery_records (request_id, user_name, delivered_at) values (rid, actor[j], t0 + make_interval(mins => offs[j])); end if;
    end loop;
    if s = -1 then
      insert into public.audit_logs (request_id, actor_name, actor_role, action, old_status, new_status, notes, created_at)
      values (rid, actor[2], 'nutricao', 'Conferência: devolvido à Cozinha', 'AGUARDANDO_CONFERENCIA_NUTRICAO', 'DEVOLVIDO_PARA_CORRECAO', 'Preparação precisa ser corrigida conforme observação registrada.', t0 + interval '35 minutes');
    end if;
  end loop;
end $$;
revoke execute on function public.seed_demo_data() from public, anon, authenticated;

create or replace function public.reset_demo_data()
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_role(auth.uid(),'admin') then raise exception 'Apenas administradores'; end if;
  perform public.seed_demo_data();
  insert into public.audit_logs (user_id, actor_name, actor_role, action, notes)
  values (auth.uid(), (select nome from public.profiles where id = auth.uid()), 'admin', 'Dados de demonstração restaurados', null);
end $$;
grant execute on function public.reset_demo_data() to authenticated;

select public.seed_demo_data();

alter publication supabase_realtime add table public.meal_requests;
