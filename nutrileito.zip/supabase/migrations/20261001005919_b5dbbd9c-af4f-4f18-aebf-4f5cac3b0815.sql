
revoke execute on function public.has_role(uuid, app_role) from public, anon;
revoke execute on function public.has_any_role(uuid) from public, anon;
revoke execute on function public.bootstrap_me() from public, anon;
revoke execute on function public.admin_set_role(uuid, app_role, boolean) from public, anon;
revoke execute on function public.admin_list_users() from public, anon;
revoke execute on function public.create_meal_request(uuid, text, text, text) from public, anon;
revoke execute on function public.transition_request(uuid, text, text, text, text) from public, anon;
revoke execute on function public.update_lead_status(uuid, text, text) from public, anon;
revoke execute on function public.update_min_delivery(int) from public, anon;
revoke execute on function public.reset_demo_data() from public, anon;
revoke execute on function public.seed_demo_data() from public, anon, authenticated;
grant execute on function public.has_role(uuid, app_role) to authenticated;
grant execute on function public.has_any_role(uuid) to authenticated;
