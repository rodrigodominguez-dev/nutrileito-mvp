<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting published git history — force pushing, or rebasing/amending/squashing commits that are already pushed — as it rewrites history on Lovable's side and the user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- NutriLeito uses database RPCs as the only write boundary for operational workflow transitions, because authorization, transition validity, timing, and audit must be atomic.
- Public marketing lives at `/`; authenticated product pages live under the `_authenticated` pathless layout, because browser sessions must not be gated during SSR.
- Demo requests are persisted and reset from a deterministic database seed, because demonstrations must cover every workflow state consistently.
