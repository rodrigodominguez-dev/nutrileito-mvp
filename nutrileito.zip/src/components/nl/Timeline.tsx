import { fmtDateTime, ROLE_LABEL, STATUS_LABEL, type Role, type Status } from "@/lib/domain";
import { useAudit } from "@/lib/data";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

export function Timeline({ requestId }: { requestId: string }) {
  const { data, isLoading } = useAudit(requestId);
  if (isLoading) return <Skeleton className="h-48 w-full" />;
  if (!data?.length) return <p className="text-sm text-muted-foreground">Sem eventos registrados.</p>;
  return (
    <ol className="relative space-y-5 border-l-2 border-border pl-6">
      {data.map((e, i) => {
        const bad = e.new_status === "DEVOLVIDO_PARA_CORRECAO" || e.new_status === "CANCELADO";
        const done = e.new_status === "ENTREGUE";
        return (
          <li key={e.id} className="relative">
            <span
              className={cn(
                "absolute -left-[33px] top-1 h-4 w-4 rounded-full border-4 border-card",
                bad ? "bg-destructive" : done ? "bg-success" : i === data.length - 1 ? "bg-primary" : "bg-primary/50",
              )}
            />
            <p className="font-mono text-xs text-muted-foreground">{fmtDateTime(e.created_at)}</p>
            <p className="font-semibold text-foreground">{e.action}</p>
            <p className="text-xs text-muted-foreground">
              {e.actor_name ?? "Sistema"}
              {e.actor_role && ` · ${ROLE_LABEL[e.actor_role as Role] ?? e.actor_role}`}
              {e.new_status && ` · ${STATUS_LABEL[e.new_status as Status] ?? e.new_status}`}
            </p>
            {e.notes && <p className="mt-1 rounded-md bg-muted px-2 py-1 text-sm text-foreground">“{e.notes}”</p>}
          </li>
        );
      })}
    </ol>
  );
}
