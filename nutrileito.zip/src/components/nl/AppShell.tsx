import type { ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard, ClipboardList, Stethoscope, CookingPot, BadgeCheck, Truck,
  BedDouble, History, Bot, ScrollText, Settings, LogOut, UsersRound, HeartPulse, ChevronDown,
} from "lucide-react";
import { useAuth } from "@/lib/auth";
import { ROLE_LABEL, type Role } from "@/lib/domain";
import {
  Sidebar, SidebarContent, SidebarFooter, SidebarGroup, SidebarGroupContent, SidebarGroupLabel,
  SidebarHeader, SidebarInset, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarProvider, SidebarTrigger,
} from "@/components/ui/sidebar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useRealtimeRequests } from "@/lib/data";

const NAV = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard, roles: ["admin","enfermagem","nutricao","cozinha","entrega"] },
  { to: "/pedidos", label: "Pedidos", icon: ClipboardList, roles: ["admin","enfermagem","nutricao","cozinha","entrega"] },
  { to: "/enfermagem", label: "Enfermagem", icon: Stethoscope, roles: ["admin","enfermagem"] },
  { to: "/nutricao", label: "Nutrição", icon: HeartPulse, roles: ["admin","nutricao"] },
  { to: "/cozinha", label: "Cozinha", icon: CookingPot, roles: ["admin","cozinha"] },
  { to: "/conferencia", label: "Conferência", icon: BadgeCheck, roles: ["admin","nutricao"] },
  { to: "/entrega", label: "Entrega", icon: Truck, roles: ["admin","entrega"] },
  { to: "/pacientes", label: "Pacientes", icon: BedDouble, roles: ["admin","enfermagem","nutricao"] },
  { to: "/historico", label: "Histórico", icon: History, roles: ["admin","nutricao"] },
  { to: "/assistente", label: "Assistente IA", icon: Bot, roles: ["admin","enfermagem","nutricao","cozinha","entrega"] },
  { to: "/leads", label: "Leads", icon: UsersRound, roles: ["admin"] },
  { to: "/auditoria", label: "Auditoria", icon: ScrollText, roles: ["admin"] },
  { to: "/usuarios", label: "Usuários", icon: UsersRound, roles: ["admin"] },
  { to: "/configuracoes", label: "Configurações", icon: Settings, roles: ["admin"] },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  useRealtimeRequests();
  const { nome, roles, activeRole, setActiveRole, signOut, loading } = useAuth();
  const path = useRouterState({ select: (s) => s.location.pathname });
  if (loading || !activeRole) return <div className="flex min-h-screen"><Skeleton className="w-64"/><div className="flex-1 p-8"><Skeleton className="h-96"/></div></div>;
  const permitted = NAV.filter((n) => (n.roles as readonly Role[]).includes(activeRole));
  return (
    <SidebarProvider>
      <Sidebar collapsible="offcanvas" className="border-sidebar-border">
        <SidebarHeader className="border-b border-sidebar-border p-5">
          <Link to="/dashboard" className="flex items-center gap-3">
            <span className="grid h-9 w-9 place-items-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground"><HeartPulse className="h-5 w-5"/></span>
            <span><b className="block font-display text-lg text-sidebar-primary-foreground">NutriLeito</b><span className="text-[10px] text-sidebar-foreground/60">GESTÃO HOSPITALAR</span></span>
          </Link>
        </SidebarHeader>
        <SidebarContent>
          <SidebarGroup>
            <SidebarGroupLabel>Navegação</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {permitted.map((n) => (
                  <SidebarMenuItem key={n.to}>
                    <SidebarMenuButton asChild isActive={path === n.to || path.startsWith(n.to + "/")} tooltip={n.label}>
                      <Link to={n.to}><n.icon/><span>{n.label}</span></Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>
        <SidebarFooter className="border-t border-sidebar-border p-3">
          <div className="rounded-lg bg-sidebar-accent p-3">
            <p className="truncate text-sm font-semibold text-sidebar-accent-foreground">{nome}</p>
            <p className="text-xs text-sidebar-foreground/65">{ROLE_LABEL[activeRole]}</p>
          </div>
          <Button variant="ghost" className="justify-start text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground" onClick={signOut}><LogOut/> Sair</Button>
        </SidebarFooter>
      </Sidebar>
      <SidebarInset>
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b bg-card/95 px-4 backdrop-blur sm:px-6">
          <SidebarTrigger />
          <DropdownMenu>
            <DropdownMenuTrigger asChild><Button variant="outline" size="sm">{ROLE_LABEL[activeRole]} <ChevronDown/></Button></DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Visualizar como</DropdownMenuLabel>
              {roles.map((r) => <DropdownMenuItem key={r} onClick={() => setActiveRole(r as Role)}>{ROLE_LABEL[r]}</DropdownMenuItem>)}
            </DropdownMenuContent>
          </DropdownMenu>
        </header>
        <main className="min-w-0 flex-1 p-4 sm:p-6 lg:p-8">{children}</main>
      </SidebarInset>
    </SidebarProvider>
  );
}
