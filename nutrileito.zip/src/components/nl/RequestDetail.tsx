import { Link } from "@tanstack/react-router";
import { ArrowLeft, AlertTriangle } from "lucide-react";
import { useRequests } from "@/lib/data";
import { RETURNED_TO_LABEL } from "@/lib/domain";
import { Button } from "@/components/ui/button";
import { Empty, Field, ListSkeleton, PageHeader, RequestHead, TimeRule } from "./ui";
import { Timeline } from "./Timeline";

export function RequestDetail({ id }: { id: string }) {
  const { data, isLoading } = useRequests();
  if (isLoading) return <ListSkeleton />;
  const request = data?.find((item) => item.id === id);
  if (!request) return <Empty title="Pedido não encontrado" text="O registro pode ter sido removido na restauração da demonstração." />;
  return <><PageHeader title={`Pedido #${String(request.number).padStart(6,"0")}`} subtitle="Detalhes e rastreabilidade completa." actions={<Button asChild variant="outline"><Link to="/pedidos"><ArrowLeft /> Voltar</Link></Button>} /><div className="grid gap-6 xl:grid-cols-[1.1fr_.9fr]"><section className="panel p-5"><RequestHead r={request}/><div className="mt-5 grid gap-3 sm:grid-cols-2"><Field label="Solicitação do paciente">“{request.patient_request}”</Field><Field label="Observação da Enfermagem">{request.nursing_notes || "Sem observações"}</Field><Field label="Dieta registrada" tone="warn">{request.patient?.diet_info_demo || "—"}<br/>{request.patient?.restrictions_demo}</Field><Field label="Refeição autorizada" tone="ok">{request.approved_meal || "Aguardando avaliação"}<br/>{request.nutrition_notes}</Field></div>{request.return_reason&&<div className="mt-3"><Field label={`Devolvido para ${RETURNED_TO_LABEL[request.returned_to ?? ""] ?? "correção"}`} tone="warn"><span className="flex gap-2"><AlertTriangle className="h-4 w-4 shrink-0"/>{request.return_reason}</span></Field></div>}<div className="mt-6"><TimeRule r={request}/></div></section><section className="panel p-5"><h2 className="mb-5 text-lg font-bold">Linha do tempo</h2><Timeline requestId={request.id}/></section></div></>;
}
