import { useState, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { Clock, Lock, CheckCircle2, Inbox } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  STATUS_LABEL,
  STATUS_TONE,
  displayStatus,
  fmtDuration,
  fmtTime,
  orderNo,
  type Tone,
  type Status,
  ROLE_LABEL,
  type Role,
} from "@/lib/domain";
import type { MealRequest } from "@/lib/data";
import { useNow } from "@/lib/data";

const TONE: Record<Tone, string> = {
  info: "bg-accent text-accent-foreground border-primary/20",
  primary: "bg-primary/10 text-primary border-primary/25",
  warning: "bg-warning/20 text-warning-foreground border-warning/50",
  success: "bg-success/12 text-success border-success/30",
  danger: "bg-destructive/10 text-destructive border-destructive/30",
  muted: "bg-muted text-muted-foreground border-border",
  navy: "bg-navy text-navy-foreground border-navy",
};

export function Pill({ tone, children, className }: { tone: Tone; children: ReactNode; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 whitespace-nowrap rounded-full border px-2.5 py-0.5 text-xs font-semibold",
        TONE[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

export function StatusBadge({ r, status }: { r?: MealRequest; status?: string }) {
  const now = useNow(5000);
  const s = (r ? displayStatus(r, now) : status) as Status;
  return <Pill tone={STATUS_TONE[s] ?? "muted"}>{STATUS_LABEL[s] ?? s}</Pill>;
}

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-2xl font-bold text-foreground sm:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function Empty({ title, text }: { title: string; text?: string }) {
  return (
    <div className="panel flex flex-col items-center justify-center px-6 py-14 text-center">
      <Inbox className="h-9 w-9 text-muted-foreground/60" aria-hidden />
      <p className="mt-3 font-semibold text-foreground">{title}</p>
      {text && <p className="mt-1 max-w-sm text-sm text-muted-foreground">{text}</p>}
    </div>
  );
}

export function ListSkeleton({ n = 3 }: { n?: number }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: n }).map((_, i) => (
        <Skeleton key={i} className="h-32 w-full rounded-xl" />
      ))}
    </div>
  );
}

export function NoAccess({ role }: { role: Role }) {
  return (
    <Empty
      title="Acesso restrito"
      text={`Esta área é exclusiva do perfil ${ROLE_LABEL[role]}. Troque de perfil no menu, se você possuir esse acesso.`}
    />
  );
}

/** Regra operacional do tempo mínimo entre criação e entrega. */
export function TimeRule({ r, compact }: { r: MealRequest; compact?: boolean }) {
  const now = useNow(1000);
  const created = new Date(r.created_at).getTime();
  const min = new Date(r.minimum_delivery_time).getTime();
  const end = r.delivered_at ? new Date(r.delivered_at).getTime() : now;
  const elapsed = end - created;
  const total = Math.max(min - created, 1);
  const pct = Math.min(100, (elapsed / total) * 100);
  const reached = end >= min;
  const remaining = min - now;
  return (
    <div className="space-y-2">
      <div className="h-2 overflow-hidden rounded-full bg-muted">
        <div
          className={cn("h-full rounded-full transition-all", reached ? "bg-success" : "bg-primary")}
          style={{ width: `${pct}%` }}
        />
      </div>
      <div className={cn("grid gap-x-4 gap-y-1 text-xs text-muted-foreground", compact ? "grid-cols-2" : "grid-cols-2 sm:grid-cols-4")}>
        <span>
          Decorrido: <b className="font-mono text-foreground">{fmtDuration(elapsed)}</b>
        </span>
        {!r.delivered_at && (
          <span>
            Restante: <b className="font-mono text-foreground">{reached ? "0min" : fmtDuration(remaining)}</b>
          </span>
        )}
        <span>
          Mínimo: <b className="font-mono text-foreground">{fmtTime(r.minimum_delivery_time)}</b>
        </span>
        {!compact && (
          <span className={cn("flex items-center gap-1 font-medium", reached ? "text-success" : "text-foreground")}>
            {reached ? <CheckCircle2 className="h-3.5 w-3.5" /> : <Clock className="h-3.5 w-3.5" />}
            {reached ? "Tempo mínimo atingido" : "Tempo mínimo ainda não atingido"}
          </span>
        )}
      </div>
    </div>
  );
}

export function DeliveryLock({ r }: { r: MealRequest }) {
  return (
    <p className="flex items-center gap-1.5 text-sm font-medium text-warning-foreground">
      <Lock className="h-4 w-4" aria-hidden /> Entrega disponível a partir das {fmtTime(r.minimum_delivery_time)}.
    </p>
  );
}

export function RequestHead({ r }: { r: MealRequest }) {
  return (
    <div className="flex flex-wrap items-start justify-between gap-2">
      <div>
        <Link
          to="/pedidos/$id"
          params={{ id: r.id }}
          className="font-mono text-xs font-semibold text-primary hover:underline"
        >
          Pedido {orderNo(r.number)}
        </Link>
        <h3 className="text-lg font-bold text-foreground">{r.patient?.nome ?? "—"}</h3>
        <p className="text-sm text-muted-foreground">
          Leito <b className="text-foreground">{r.patient?.leito}</b> · {r.patient?.unidade} · {r.meal_type} ·{" "}
          {fmtTime(r.created_at)}
        </p>
      </div>
      <StatusBadge r={r} />
    </div>
  );
}

export function Field({ label, children, tone }: { label: string; children: ReactNode; tone?: "warn" | "ok" }) {
  return (
    <div
      className={cn(
        "rounded-lg border px-3 py-2",
        tone === "warn" ? "border-warning/50 bg-warning/10" : tone === "ok" ? "border-success/30 bg-success/5" : "bg-muted/40",
      )}
    >
      <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{label}</p>
      <div className="mt-0.5 text-sm text-foreground">{children}</div>
    </div>
  );
}

/** Diálogo que exige um texto (motivo/observação) antes de confirmar uma ação crítica. */
export function ReasonDialog({
  open,
  onOpenChange,
  title,
  description,
  label = "Motivo",
  confirm,
  destructive,
  required = true,
  onConfirm,
  pending,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  title: string;
  description?: string;
  label?: string;
  confirm: string;
  destructive?: boolean;
  required?: boolean;
  onConfirm: (text: string) => void;
  pending?: boolean;
}) {
  const [text, setText] = useState("");
  const invalid = required && text.trim().length < 3;
  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o) setText("");
        onOpenChange(o);
      }}
    >
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>
        <div className="space-y-2">
          <Label htmlFor="reason">
            {label}
            {required && " *"}
          </Label>
          <Textarea id="reason" value={text} maxLength={1000} onChange={(e) => setText(e.target.value)} rows={4} />
          {required && <p className="text-xs text-muted-foreground">Obrigatório. Ficará registrado na timeline e auditoria.</p>}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button
            variant={destructive ? "destructive" : "default"}
            disabled={invalid || pending}
            onClick={() => {
              onConfirm(text.trim());
              setText("");
            }}
          >
            {confirm}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function Stat({ label, value, tone = "primary", hint }: { label: string; value: ReactNode; tone?: Tone; hint?: string }) {
  const bar: Record<Tone, string> = {
    info: "bg-accent-foreground",
    primary: "bg-primary",
    warning: "bg-warning",
    success: "bg-success",
    danger: "bg-destructive",
    muted: "bg-muted-foreground",
    navy: "bg-navy",
  };
  return (
    <div className="panel relative overflow-hidden p-4">
      <span className={cn("absolute left-0 top-0 h-full w-1", bar[tone])} />
      <p className="text-xs font-medium text-muted-foreground">{label}</p>
      <p className="mt-1 font-display text-3xl font-bold text-foreground">{value}</p>
      {hint && <p className="mt-0.5 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}
