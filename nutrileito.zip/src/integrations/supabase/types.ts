export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      ai_logs: {
        Row: {
          agent: string
          created_at: string
          id: string
          interaction: string | null
          request_id: string | null
          user_id: string | null
        }
        Insert: {
          agent: string
          created_at?: string
          id?: string
          interaction?: string | null
          request_id?: string | null
          user_id?: string | null
        }
        Update: {
          agent?: string
          created_at?: string
          id?: string
          interaction?: string | null
          request_id?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      app_settings: {
        Row: {
          id: number
          min_delivery_minutes: number
          updated_at: string
        }
        Insert: {
          id?: number
          min_delivery_minutes?: number
          updated_at?: string
        }
        Update: {
          id?: number
          min_delivery_minutes?: number
          updated_at?: string
        }
        Relationships: []
      }
      audit_logs: {
        Row: {
          action: string
          actor_name: string | null
          actor_role: string | null
          created_at: string
          id: string
          new_status: string | null
          notes: string | null
          old_status: string | null
          request_id: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          actor_name?: string | null
          actor_role?: string | null
          created_at?: string
          id?: string
          new_status?: string | null
          notes?: string | null
          old_status?: string | null
          request_id?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          actor_name?: string | null
          actor_role?: string | null
          created_at?: string
          id?: string
          new_status?: string | null
          notes?: string | null
          old_status?: string | null
          request_id?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "audit_logs_request_id_fkey"
            columns: ["request_id"]
            isOneToOne: false
            referencedRelation: "meal_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      clients: {
        Row: {
          cargo: string | null
          contato_nome: string | null
          created_at: string
          email: string | null
          fase: string
          id: string
          instituicao: string
          lead_id: string | null
          leitos: number | null
          whatsapp: string | null
        }
        Insert: {
          cargo?: string | null
          contato_nome?: string | null
          created_at?: string
          email?: string | null
          fase?: string
          id?: string
          instituicao: string
          lead_id?: string | null
          leitos?: number | null
          whatsapp?: string | null
        }
        Update: {
          cargo?: string | null
          contato_nome?: string | null
          created_at?: string
          email?: string | null
          fase?: string
          id?: string
          instituicao?: string
          lead_id?: string | null
          leitos?: number | null
          whatsapp?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "clients_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: true
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      delivery_records: {
        Row: {
          delivered_at: string
          id: string
          notes: string | null
          request_id: string
          user_id: string | null
          user_name: string | null
        }
        Insert: {
          delivered_at?: string
          id?: string
          notes?: string | null
          request_id: string
          user_id?: string | null
          user_name?: string | null
        }
        Update: {
          delivered_at?: string
          id?: string
          notes?: string | null
          request_id?: string
          user_id?: string | null
          user_name?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "delivery_records_request_id_fkey"
            columns: ["request_id"]
            isOneToOne: false
            referencedRelation: "meal_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      kitchen_actions: {
        Row: {
          action: string
          created_at: string
          id: string
          notes: string | null
          request_id: string
          user_id: string | null
          user_name: string | null
        }
        Insert: {
          action: string
          created_at?: string
          id?: string
          notes?: string | null
          request_id: string
          user_id?: string | null
          user_name?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          id?: string
          notes?: string | null
          request_id?: string
          user_id?: string | null
          user_name?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "kitchen_actions_request_id_fkey"
            columns: ["request_id"]
            isOneToOne: false
            referencedRelation: "meal_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      leads: {
        Row: {
          cargo: string
          created_at: string
          dificuldade: string | null
          email: string
          fluxo_atual: string | null
          id: string
          instituicao: string
          leitos: number | null
          nome: string
          notas: string | null
          status: string
          updated_at: string
          whatsapp: string
        }
        Insert: {
          cargo: string
          created_at?: string
          dificuldade?: string | null
          email: string
          fluxo_atual?: string | null
          id?: string
          instituicao: string
          leitos?: number | null
          nome: string
          notas?: string | null
          status?: string
          updated_at?: string
          whatsapp: string
        }
        Update: {
          cargo?: string
          created_at?: string
          dificuldade?: string | null
          email?: string
          fluxo_atual?: string | null
          id?: string
          instituicao?: string
          leitos?: number | null
          nome?: string
          notas?: string | null
          status?: string
          updated_at?: string
          whatsapp?: string
        }
        Relationships: []
      }
      meal_requests: {
        Row: {
          approved_meal: string | null
          created_at: string
          created_by: string | null
          created_by_name: string | null
          delivered_at: string | null
          id: string
          meal_type: string
          minimum_delivery_time: string
          number: number
          nursing_notes: string | null
          nutrition_notes: string | null
          patient_id: string
          patient_request: string
          return_reason: string | null
          returned_to: string | null
          status: string
          updated_at: string
        }
        Insert: {
          approved_meal?: string | null
          created_at?: string
          created_by?: string | null
          created_by_name?: string | null
          delivered_at?: string | null
          id?: string
          meal_type: string
          minimum_delivery_time: string
          number?: number
          nursing_notes?: string | null
          nutrition_notes?: string | null
          patient_id: string
          patient_request: string
          return_reason?: string | null
          returned_to?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          approved_meal?: string | null
          created_at?: string
          created_by?: string | null
          created_by_name?: string | null
          delivered_at?: string | null
          id?: string
          meal_type?: string
          minimum_delivery_time?: string
          number?: number
          nursing_notes?: string | null
          nutrition_notes?: string | null
          patient_id?: string
          patient_request?: string
          return_reason?: string | null
          returned_to?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "meal_requests_patient_id_fkey"
            columns: ["patient_id"]
            isOneToOne: false
            referencedRelation: "patients"
            referencedColumns: ["id"]
          },
        ]
      }
      nutrition_reviews: {
        Row: {
          approved_meal: string | null
          created_at: string
          decision: string
          id: string
          notes: string | null
          request_id: string
          reviewer_id: string | null
          reviewer_name: string | null
        }
        Insert: {
          approved_meal?: string | null
          created_at?: string
          decision: string
          id?: string
          notes?: string | null
          request_id: string
          reviewer_id?: string | null
          reviewer_name?: string | null
        }
        Update: {
          approved_meal?: string | null
          created_at?: string
          decision?: string
          id?: string
          notes?: string | null
          request_id?: string
          reviewer_id?: string | null
          reviewer_name?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "nutrition_reviews_request_id_fkey"
            columns: ["request_id"]
            isOneToOne: false
            referencedRelation: "meal_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      patients: {
        Row: {
          created_at: string
          diet_info_demo: string | null
          id: string
          leito: string
          nome: string
          restrictions_demo: string | null
          status: string
          unidade: string
        }
        Insert: {
          created_at?: string
          diet_info_demo?: string | null
          id?: string
          leito: string
          nome: string
          restrictions_demo?: string | null
          status?: string
          unidade: string
        }
        Update: {
          created_at?: string
          diet_info_demo?: string | null
          id?: string
          leito?: string
          nome?: string
          restrictions_demo?: string | null
          status?: string
          unidade?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          email: string | null
          id: string
          nome: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          id: string
          nome?: string
        }
        Update: {
          created_at?: string
          email?: string | null
          id?: string
          nome?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_list_users: {
        Args: never
        Returns: {
          email: string
          id: string
          nome: string
          roles: string[]
        }[]
      }
      admin_set_role: {
        Args: {
          _grant: boolean
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: undefined
      }
      bootstrap_me: { Args: never; Returns: undefined }
      create_meal_request: {
        Args: {
          _meal_type: string
          _nursing_notes: string
          _patient_id: string
          _patient_request: string
        }
        Returns: string
      }
      has_any_role: { Args: { _user_id: string }; Returns: boolean }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      reset_demo_data: { Args: never; Returns: undefined }
      seed_demo_data: { Args: never; Returns: undefined }
      transition_request: {
        Args: {
          _action: string
          _approved_meal?: string
          _id: string
          _notes?: string
          _request_text?: string
        }
        Returns: string
      }
      update_lead_status: {
        Args: { _id: string; _notas?: string; _status: string }
        Returns: undefined
      }
      update_min_delivery: { Args: { _mins: number }; Returns: undefined }
    }
    Enums: {
      app_role: "admin" | "enfermagem" | "nutricao" | "cozinha" | "entrega"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "enfermagem", "nutricao", "cozinha", "entrega"],
    },
  },
} as const
