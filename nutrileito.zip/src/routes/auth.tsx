import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { HeartPulse, ArrowLeft, ShieldCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export const Route = createFileRoute("/auth")({
  head: () => ({ meta: [
    { title: "Acessar demonstração — NutriLeito" },
    { name: "description", content: "Acesse a demonstração segura do sistema NutriLeito." },
    { property: "og:title", content: "Demonstração — NutriLeito" },
    { property: "og:description", content: "Acesse a demonstração do fluxo de refeições hospitalares." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ]}),
  component: AuthPage,
});

function AuthPage() {
  const [signup, setSignup] = useState(false);
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true);
    const fd = new FormData(e.currentTarget);
    const nome = String(fd.get("nome") ?? "").trim();
    const email = String(fd.get("email") ?? "").trim();
    const password = String(fd.get("password") ?? "");
    try {
      if (!email || password.length < 8 || (signup && nome.length < 2)) throw new Error("Revise os campos. A senha deve ter ao menos 8 caracteres.");
      if (signup) {
        const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { nome } } });
        if (error) throw error;
        if (!data.session) { toast.success("Cadastro criado. Confirme seu e-mail para entrar."); setSignup(false); return; }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
      navigate({ to: "/dashboard" });
    } catch (err) { toast.error(err instanceof Error ? err.message : "Não foi possível entrar"); }
    finally { setBusy(false); }
  }
  return <div className="grid min-h-screen lg:grid-cols-[1.1fr_.9fr]">
    <aside className="hidden bg-navy p-12 text-navy-foreground lg:flex lg:flex-col lg:justify-between">
      <Link to="/" className="flex items-center gap-3 font-display text-xl font-bold"><span className="grid h-10 w-10 place-items-center rounded-lg bg-primary"><HeartPulse/></span>NutriLeito</Link>
      <div className="max-w-xl"><p className="mb-4 text-sm font-semibold uppercase text-primary">Demonstração segura</p><h1 className="text-5xl font-bold leading-tight">Do pedido do paciente à entrega no leito.</h1><p className="mt-5 text-lg text-navy-foreground/70">Acompanhe o fluxo completo com dados fictícios, perfis profissionais e rastreabilidade de cada etapa.</p></div>
      <p className="flex items-center gap-2 text-sm text-navy-foreground/65"><ShieldCheck/> Ambiente demonstrativo. Não use dados reais de pacientes.</p>
    </aside>
    <main className="flex items-center justify-center p-6 sm:p-10">
      <div className="w-full max-w-md">
        <Link to="/" className="mb-10 inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"><ArrowLeft className="h-4 w-4"/> Voltar</Link>
        <div className="mb-7 lg:hidden"><HeartPulse className="h-9 w-9 text-primary"/><b className="mt-2 block font-display text-xl">NutriLeito</b></div>
        <h2 className="text-3xl font-bold">{signup ? "Criar acesso" : "Acessar demonstração"}</h2>
        <p className="mt-2 text-sm text-muted-foreground">{signup ? "O primeiro cadastro recebe acesso completo para configurar a demonstração." : "Entre com seu e-mail e senha."}</p>
        <form className="mt-7 space-y-4" onSubmit={submit}>
          {signup && <div><Label htmlFor="nome">Nome</Label><Input id="nome" name="nome" required minLength={2} maxLength={100}/></div>}
          <div><Label htmlFor="email">E-mail</Label><Input id="email" name="email" type="email" required maxLength={255}/></div>
          <div><Label htmlFor="password">Senha</Label><Input id="password" name="password" type="password" required minLength={8} maxLength={72}/></div>
          <Button className="w-full" size="lg" disabled={busy}>{busy ? "Aguarde…" : signup ? "Criar acesso" : "Entrar"}</Button>
        </form>
        <Button variant="link" className="mt-3 w-full" onClick={() => setSignup(!signup)}>{signup ? "Já tenho acesso" : "Criar meu acesso demonstrativo"}</Button>
      </div>
    </main>
  </div>;
}
