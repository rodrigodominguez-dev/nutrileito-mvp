import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, BadgeCheck, BarChart3, Bot, Check, ClipboardCheck, Clock3, HeartPulse, ShieldCheck, Sparkles, UtensilsCrossed } from "lucide-react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "NutriLeito — Gestão inteligente de refeições hospitalares" },
    { name: "description", content: "Centralize e acompanhe o fluxo de refeições hospitalares da solicitação à entrega no leito." },
    { property: "og:title", content: "NutriLeito — Gestão inteligente de refeições hospitalares" },
    { property: "og:description", content: "Centralize e acompanhe o fluxo de refeições hospitalares da solicitação à entrega no leito." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ]}), component: Landing,
});

const leadSchema = z.object({
  nome: z.string().trim().min(2).max(100), instituicao: z.string().trim().min(2).max(150), cargo: z.string().trim().min(2).max(100),
  email: z.string().trim().email().max(255), whatsapp: z.string().trim().min(8).max(25).regex(/^[+\d\s()-]+$/), leitos: z.coerce.number().int().min(1).max(100000),
  fluxo_atual: z.string().trim().max(1500), dificuldade: z.string().trim().max(1500),
});
const FLOW = ["Paciente solicita", "Enfermagem registra", "Nutrição avalia", "Cozinha prepara", "Nutrição confere", "Entrega no leito"];
const BENEFITS = [
  [ClipboardCheck,"Centralização dos pedidos","Uma única visão entre Enfermagem, Nutrição, Cozinha e Entrega."],
  [BadgeCheck,"Rastreabilidade por etapa","Responsável, horário, decisão e histórico em cada mudança."],
  [Clock3,"Controle operacional","Tempo mínimo configurável, contadores e alertas de atenção."],
  [BarChart3,"Gestão com clareza","Indicadores operacionais e funil comercial no mesmo painel."],
  [ShieldCheck,"Conferência e auditoria","A refeição retorna à Nutrição antes de seguir ao leito."],
  [Bot,"Assistência por IA","Apoio para resumir e monitorar — nunca para decidir clinicamente."],
] as const;
function Landing() {
  const [sent, setSent] = useState(false); const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true);
    try {
      const raw = Object.fromEntries(new FormData(e.currentTarget)); const v = leadSchema.safeParse(raw);
      if (!v.success) throw new Error("Revise os campos do formulário.");
      const { error } = await supabase.from("leads").insert(v.data); if (error) throw error;
      setSent(true); toast.success("Contato recebido com sucesso.");
    } catch (err) { toast.error(err instanceof Error ? err.message : "Não foi possível enviar"); }
    finally { setBusy(false); }
  }
  return <div className="bg-background">
    <header className="sticky top-0 z-40 border-b bg-card/90 backdrop-blur"><div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5">
      <Link to="/" className="flex items-center gap-2 font-display text-xl font-bold"><span className="grid h-8 w-8 place-items-center rounded-md bg-primary text-primary-foreground"><HeartPulse className="h-4 w-4"/></span>NutriLeito</Link>
      <nav className="hidden gap-7 text-sm font-medium md:flex"><a href="#solucao">A solução</a><a href="#como-funciona">Como funciona</a><a href="#demonstracao">Demonstração</a></nav>
      <Button asChild size="sm"><Link to="/auth">Conhecer o sistema</Link></Button>
    </div></header>
    <main>
      <section className="bg-hero overflow-hidden border-b"><div className="mx-auto grid min-h-[calc(100svh-4rem)] max-w-7xl items-center gap-12 px-5 py-16 lg:grid-cols-[1fr_.9fr] lg:py-24">
        <div><p className="mb-5 inline-flex items-center gap-2 rounded-full border border-primary/25 bg-primary/5 px-3 py-1 text-xs font-bold text-primary"><Sparkles className="h-3.5 w-3.5"/>FLUXO HOSPITALAR RASTREÁVEL</p>
          <h1 className="text-5xl font-extrabold leading-[1.05] text-navy sm:text-6xl lg:text-7xl">NutriLeito</h1>
          <h2 className="mt-4 max-w-2xl text-2xl font-semibold leading-tight text-foreground sm:text-3xl">Do pedido do paciente à entrega no leito.</h2>
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground">Centralize, acompanhe e rastreie o fluxo de refeições hospitalares em uma única plataforma.</p>
          <div className="mt-8 flex flex-wrap gap-3"><Button asChild size="lg"><a href="#demonstracao">Solicitar demonstração <ArrowRight/></a></Button><Button asChild variant="outline" size="lg"><Link to="/auth">Conhecer o sistema</Link></Button></div>
          <p className="mt-7 flex items-center gap-2 text-xs text-muted-foreground"><ShieldCheck className="h-4 w-4 text-success"/> MVP demonstrativo com dados exclusivamente fictícios.</p>
        </div>
        <div className="relative">
          <div className="panel shadow-lift overflow-hidden"><div className="flex items-center justify-between border-b px-5 py-4"><div><p className="text-xs text-muted-foreground">Fluxo agora</p><p className="font-bold">Operação de refeições</p></div><span className="rounded-full bg-success/10 px-2 py-1 text-xs font-semibold text-success">● Ao vivo</span></div>
            <div className="grid grid-cols-2 gap-px bg-border sm:grid-cols-3">{[["18","Pedidos hoje"],["4","Nutrição"],["3","Em preparo"],["2","Conferência"],["3","Entrega"],["6","Entregues"]].map(([v,l])=><div key={l} className="bg-card p-4"><p className="font-display text-2xl font-bold">{v}</p><p className="text-xs text-muted-foreground">{l}</p></div>)}</div>
            <div className="p-5"><p className="mb-4 text-xs font-bold uppercase text-muted-foreground">Pedido #000123</p><div className="space-y-3">{["Enfermagem registrou","Nutrição liberou","Cozinha iniciou preparo","Conferência final","Entrega no leito"].map((x,i)=><div key={x} className="flex items-center gap-3"><span className={`grid h-6 w-6 place-items-center rounded-full ${i<3?'bg-success text-success-foreground':'bg-muted text-muted-foreground'}`}>{i<3?<Check className="h-3.5 w-3.5"/>:i+1}</span><span className={i<3?'text-sm font-medium':'text-sm text-muted-foreground'}>{x}</span>{i===2&&<span className="ml-auto rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-bold text-primary">AGORA</span>}</div>)}</div></div>
          </div>
        </div>
      </div></section>
      <section id="solucao" className="mx-auto max-w-7xl px-5 py-24"><div className="max-w-3xl"><p className="text-sm font-bold text-primary">UMA OPERAÇÃO, UMA FONTE DE VERDADE</p><h2 className="mt-3 text-4xl font-bold">Menos ruído entre setores. Mais visibilidade para cada refeição.</h2><p className="mt-4 text-muted-foreground">Pedidos hospitalares atravessam equipes, decisões e conferências. O NutriLeito organiza esse percurso sem substituir a responsabilidade clínica.</p></div>
        <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-3">{BENEFITS.map(([Icon,t,d])=><div key={t} className="panel p-6"><span className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary"><Icon/></span><h3 className="mt-5 text-lg font-bold">{t}</h3><p className="mt-2 text-sm leading-relaxed text-muted-foreground">{d}</p></div>)}</div>
      </section>
      <section id="como-funciona" className="border-y bg-navy py-24 text-navy-foreground"><div className="mx-auto max-w-7xl px-5"><p className="text-sm font-bold text-primary">COMO FUNCIONA</p><h2 className="mt-3 text-4xl font-bold">Da solicitação verbal à confirmação no leito.</h2><div className="mt-12 grid gap-5 md:grid-cols-3 lg:grid-cols-6">{FLOW.map((x,i)=><div key={x}><span className="font-mono text-xs text-primary">0{i+1}</span><div className="my-3 h-px bg-sidebar-border"/><p className="font-semibold">{x}</p></div>)}</div><div className="mt-12 rounded-lg border border-sidebar-border bg-sidebar-accent p-5 text-sm text-navy-foreground/75"><b className="text-navy-foreground">Responsabilidade clínica preservada:</b> a IA organiza e sinaliza informações, mas toda avaliação e liberação nutricional é confirmada por profissional autorizado.</div></div></section>
      <section id="demonstracao" className="mx-auto grid max-w-7xl gap-14 px-5 py-24 lg:grid-cols-[.8fr_1.2fr]"><div><p className="text-sm font-bold text-primary">FALE COM A GENTE</p><h2 className="mt-3 text-4xl font-bold">Solicite uma demonstração</h2><p className="mt-5 leading-relaxed text-muted-foreground">O NutriLeito busca validar se hospitais e instituições de saúde têm interesse em centralizar, rastrear e organizar o fluxo de refeições dos pacientes.</p><ul className="mt-8 space-y-3 text-sm">{["Conheça o fluxo ponta a ponta","Avalie a aderência à sua operação","Contato comercial manual, sem compromisso"].map(x=><li key={x} className="flex gap-2"><Check className="h-5 w-5 text-success"/>{x}</li>)}</ul></div>
        <div className="panel p-6 sm:p-8">{sent?<div className="flex min-h-96 flex-col items-center justify-center text-center"><span className="grid h-14 w-14 place-items-center rounded-full bg-success/10 text-success"><Check className="h-7 w-7"/></span><h3 className="mt-5 text-2xl font-bold">Recebemos seu contato</h3><p className="mt-3 max-w-md text-muted-foreground">Nossa equipe poderá entrar em contato para apresentar o NutriLeito.</p></div>:<form onSubmit={submit} className="grid gap-4 sm:grid-cols-2"><div><Label>Nome *</Label><Input name="nome" required maxLength={100}/></div><div><Label>Hospital ou instituição *</Label><Input name="instituicao" required maxLength={150}/></div><div><Label>Cargo *</Label><Input name="cargo" required maxLength={100}/></div><div><Label>E-mail *</Label><Input type="email" name="email" required maxLength={255}/></div><div><Label>WhatsApp *</Label><Input name="whatsapp" required maxLength={25} placeholder="(11) 99999-9999"/></div><div><Label>Quantidade aproximada de leitos *</Label><Input type="number" name="leitos" required min={1} max={100000}/></div><div className="sm:col-span-2"><Label>Como o fluxo de alimentação funciona atualmente?</Label><Textarea name="fluxo_atual" maxLength={1500}/></div><div className="sm:col-span-2"><Label>Qual é a principal dificuldade encontrada hoje?</Label><Textarea name="dificuldade" maxLength={1500}/></div><Button className="sm:col-span-2" size="lg" disabled={busy}>{busy?"Enviando…":"Quero conhecer o NutriLeito"}</Button></form>}</div>
      </section>
    </main>
    <footer className="border-t bg-card"><div className="mx-auto flex max-w-7xl flex-col gap-4 px-5 py-8 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between"><p className="flex items-center gap-2 font-semibold text-foreground"><UtensilsCrossed className="h-4 w-4 text-primary"/>NutriLeito</p><p>Protótipo educacional — use apenas dados fictícios.</p></div></footer>
  </div>;
}
