import { createFileRoute } from "@tanstack/react-router";
import { KitchenPage } from "@/components/nl/OperationalPages";
export const Route = createFileRoute("/_authenticated/cozinha")({
  head: () => ({ meta: [
    { title: "Cozinha — NutriLeito" },
    { name: "description", content: "Acompanhe a fila de produção das refeições autorizadas." },
    { property: "og:title", content: "Cozinha — NutriLeito" },
    { property: "og:description", content: "Acompanhe a fila de produção das refeições autorizadas." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ]}),
  component: KitchenPage,
});
