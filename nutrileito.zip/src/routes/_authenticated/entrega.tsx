import { createFileRoute } from "@tanstack/react-router";
import { DeliveryPage } from "@/components/nl/OperationalPages";
export const Route = createFileRoute("/_authenticated/entrega")({
  head: () => ({ meta: [
    { title: "Entrega — NutriLeito" },
    { name: "description", content: "Confirme a entrega de refeições liberadas aos leitos." },
    { property: "og:title", content: "Entrega — NutriLeito" },
    { property: "og:description", content: "Confirme a entrega de refeições liberadas aos leitos." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ]}),
  component: DeliveryPage,
});
