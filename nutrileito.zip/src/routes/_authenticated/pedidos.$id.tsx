import { createFileRoute } from "@tanstack/react-router";
import { RequestDetail } from "@/components/nl/RequestDetail";
export const Route = createFileRoute("/_authenticated/pedidos/$id")({
  head: () => ({ meta: [
    { title: "Detalhes do pedido — NutriLeito" }, { name: "description", content: "Consulte os detalhes e a linha do tempo do pedido." },
    { property: "og:title", content: "Detalhes do pedido — NutriLeito" }, { property: "og:description", content: "Consulte os detalhes e a linha do tempo do pedido." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ]}), component: DetailRoute,
});
function DetailRoute(){ const { id } = Route.useParams(); return <RequestDetail id={id}/>; }
