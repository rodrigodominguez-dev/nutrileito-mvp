import { createFileRoute } from "@tanstack/react-router";
import { UsersPage } from "@/components/nl/AdminPages";
export const Route = createFileRoute("/_authenticated/usuarios")({
  head: () => ({ meta: [
    { title: "Usuários — NutriLeito" },
    { name: "description", content: "Gerencie os perfis de acesso dos usuários." },
    { property: "og:title", content: "Usuários — NutriLeito" },
    { property: "og:description", content: "Gerencie os perfis de acesso dos usuários." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ]}),
  component: UsersPage,
});
