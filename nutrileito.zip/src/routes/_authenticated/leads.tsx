import { createFileRoute } from "@tanstack/react-router";
import { LeadsPage } from "@/components/nl/AdminPages";
export const Route = createFileRoute("/_authenticated/leads")({
  head: () => ({ meta: [
    { title: "Leads — NutriLeito" },
    { name: "description", content: "Gerencie contatos e oportunidades comerciais do NutriLeito." },
    { property: "og:title", content: "Leads — NutriLeito" },
    { property: "og:description", content: "Gerencie contatos e oportunidades comerciais do NutriLeito." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ]}),
  component: LeadsPage,
});
