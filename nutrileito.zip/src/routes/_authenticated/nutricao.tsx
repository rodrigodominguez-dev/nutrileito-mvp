import { createFileRoute } from "@tanstack/react-router";
import { NutritionPage } from "@/components/nl/OperationalPages";
export const Route = createFileRoute("/_authenticated/nutricao")({
  head: () => ({ meta: [
    { title: "Nutrição — NutriLeito" },
    { name: "description", content: "Avalie solicitações e autorize refeições para produção." },
    { property: "og:title", content: "Nutrição — NutriLeito" },
    { property: "og:description", content: "Avalie solicitações e autorize refeições para produção." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ]}),
  component: NutritionPage,
});
