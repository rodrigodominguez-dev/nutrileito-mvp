import { createFileRoute } from "@tanstack/react-router";
import { OrdersPage } from "@/components/nl/OperationalPages";
export const Route = createFileRoute("/_authenticated/pedidos")({
  head: () => ({ meta: [
    { title: "Pedidos — NutriLeito" },
    { name: "description", content: "Acompanhe todas as solicitações de refeições hospitalares." },
    { property: "og:title", content: "Pedidos — NutriLeito" },
    { property: "og:description", content: "Acompanhe todas as solicitações de refeições hospitalares." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ]}),
  component: OrdersPage,
});
