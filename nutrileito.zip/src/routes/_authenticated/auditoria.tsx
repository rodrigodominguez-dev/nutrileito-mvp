import { createFileRoute } from "@tanstack/react-router";
import { AuditPage } from "@/components/nl/AdminPages";
export const Route = createFileRoute("/_authenticated/auditoria")({
  head: () => ({ meta: [
    { title: "Auditoria — NutriLeito" },
    { name: "description", content: "Consulte o histórico imutável de ações do sistema." },
    { property: "og:title", content: "Auditoria — NutriLeito" },
    { property: "og:description", content: "Consulte o histórico imutável de ações do sistema." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ]}),
  component: AuditPage,
});
