import { createFileRoute } from "@tanstack/react-router";
import { SettingsPage } from "@/components/nl/AdminPages";
export const Route = createFileRoute("/_authenticated/configuracoes")({
  head: () => ({ meta: [
    { title: "Configurações — NutriLeito" },
    { name: "description", content: "Configure as regras do ambiente demonstrativo." },
    { property: "og:title", content: "Configurações — NutriLeito" },
    { property: "og:description", content: "Configure as regras do ambiente demonstrativo." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ]}),
  component: SettingsPage,
});
