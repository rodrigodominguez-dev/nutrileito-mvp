import { createFileRoute } from "@tanstack/react-router";
import { NursingPage } from "@/components/nl/NursingPage";
export const Route = createFileRoute("/_authenticated/enfermagem")({
  head: () => ({ meta: [
    { title: "Enfermagem — NutriLeito" },
    { name: "description", content: "Registre e acompanhe solicitações de refeições dos pacientes." },
    { property: "og:title", content: "Enfermagem — NutriLeito" },
    { property: "og:description", content: "Registre e acompanhe solicitações de refeições dos pacientes." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ]}),
  component: NursingPage,
});
