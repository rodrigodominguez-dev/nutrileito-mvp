import { createFileRoute } from "@tanstack/react-router";
import { ConferencePage } from "@/components/nl/OperationalPages";
export const Route = createFileRoute("/_authenticated/conferencia")({
  head: () => ({ meta: [
    { title: "Conferência — NutriLeito" },
    { name: "description", content: "Confira refeições prontas antes da entrega ao leito." },
    { property: "og:title", content: "Conferência — NutriLeito" },
    { property: "og:description", content: "Confira refeições prontas antes da entrega ao leito." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ]}),
  component: ConferencePage,
});
