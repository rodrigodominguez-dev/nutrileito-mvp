import { createFileRoute } from "@tanstack/react-router";
import { OrdersPage } from "@/components/nl/OperationalPages";
export const Route = createFileRoute("/_authenticated/historico")({ head: () => ({ meta: [
  { title: "Histórico — NutriLeito" }, { name: "description", content: "Consulte pedidos hospitalares concluídos e cancelados." },
  { property: "og:title", content: "Histórico — NutriLeito" }, { property: "og:description", content: "Consulte pedidos hospitalares concluídos e cancelados." },
  { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
]}), component: () => <OrdersPage history /> });
