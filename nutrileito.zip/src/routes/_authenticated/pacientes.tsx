import { createFileRoute } from "@tanstack/react-router";
import { PatientsPage } from "@/components/nl/AdminPages";
export const Route = createFileRoute("/_authenticated/pacientes")({
  head: () => ({ meta: [
    { title: "Pacientes — NutriLeito" },
    { name: "description", content: "Consulte os pacientes fictícios do ambiente demonstrativo." },
    { property: "og:title", content: "Pacientes — NutriLeito" },
    { property: "og:description", content: "Consulte os pacientes fictícios do ambiente demonstrativo." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ]}),
  component: PatientsPage,
});
