import { createFileRoute } from "@tanstack/react-router";
import { Dashboard } from "@/components/nl/Dashboard";
export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [
    { title: "Dashboard — NutriLeito" },
    { name: "description", content: "Visão geral da operação e do funil comercial." },
    { property: "og:title", content: "Dashboard — NutriLeito" },
    { property: "og:description", content: "Visão geral da operação e do funil comercial." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ]}),
  component: Dashboard,
});
