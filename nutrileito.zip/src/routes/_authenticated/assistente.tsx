import { createFileRoute } from "@tanstack/react-router";
import { AiAssistant } from "@/components/nl/AiAssistant";
export const Route = createFileRoute("/_authenticated/assistente")({
  head: () => ({ meta: [
    { title: "Assistente operacional — NutriLeito" },
    { name: "description", content: "Consulte resumos operacionais sem decisões clínicas." },
    { property: "og:title", content: "Assistente operacional — NutriLeito" },
    { property: "og:description", content: "Consulte resumos operacionais sem decisões clínicas." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ]}),
  component: AiAssistant,
});
