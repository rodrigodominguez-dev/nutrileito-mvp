import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { ROLES, type Role } from "./domain";

type Ctx = {
  user: User;
  nome: string;
  roles: Role[];
  activeRole: Role | null;
  setActiveRole: (r: Role) => void;
  loading: boolean;
  signOut: () => Promise<void>;
};
const AuthCtx = createContext<Ctx | null>(null);

export function AuthProvider({ user, children }: { user: User; children: ReactNode }) {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["me", user.id],
    queryFn: async () => {
      await supabase.rpc("bootstrap_me");
      const [{ data: roles }, { data: profile }] = await Promise.all([
        supabase.from("user_roles").select("role").eq("user_id", user.id),
        supabase.from("profiles").select("nome").eq("id", user.id).maybeSingle(),
      ]);
      const list = (roles ?? []).map((r) => r.role as Role);
      return { roles: ROLES.filter((r) => list.includes(r)), nome: profile?.nome ?? user.email ?? "" };
    },
  });
  const [activeRole, setActive] = useState<Role | null>(null);
  useEffect(() => {
    if (!data) return;
    const saved = localStorage.getItem("nl-active-role") as Role | null;
    setActive(saved && data.roles.includes(saved) ? saved : (data.roles[0] ?? null));
  }, [data]);

  const value: Ctx = {
    user,
    nome: data?.nome ?? "",
    roles: data?.roles ?? [],
    activeRole,
    setActiveRole: (r) => {
      localStorage.setItem("nl-active-role", r);
      setActive(r);
    },
    loading: isLoading,
    signOut: async () => {
      await supabase.auth.signOut();
      qc.clear();
      window.location.href = "/auth";
    },
  };
  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}

export function useAuth() {
  const c = useContext(AuthCtx);
  if (!c) throw new Error("useAuth fora do AuthProvider");
  return c;
}
