import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

export type Patient = {
  id: string;
  nome: string;
  leito: string;
  unidade: string;
  status: string;
  diet_info_demo: string | null;
  restrictions_demo: string | null;
};
export type MealRequest = {
  id: string;
  number: number;
  patient_id: string;
  meal_type: string;
  patient_request: string;
  nursing_notes: string | null;
  approved_meal: string | null;
  nutrition_notes: string | null;
  status: string;
  returned_to: string | null;
  return_reason: string | null;
  created_by_name: string | null;
  created_at: string;
  updated_at: string;
  minimum_delivery_time: string;
  delivered_at: string | null;
  patient: Patient | null;
};
export type AuditLog = {
  id: string;
  request_id: string | null;
  actor_name: string | null;
  actor_role: string | null;
  action: string;
  old_status: string | null;
  new_status: string | null;
  notes: string | null;
  created_at: string;
};

export function useNow(interval = 1000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), interval);
    return () => clearInterval(t);
  }, [interval]);
  return now;
}

export function useRealtimeRequests() {
  const qc = useQueryClient();
  useEffect(() => {
    const ch = supabase
      .channel("meal_requests_live")
      .on("postgres_changes", { event: "*", schema: "public", table: "meal_requests" }, () => {
        qc.invalidateQueries({ queryKey: ["requests"] });
        qc.invalidateQueries({ queryKey: ["audit"] });
      })
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);
}

export function useRequests() {
  return useQuery({
    queryKey: ["requests"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("meal_requests")
        .select("*, patient:patients(*)")
        .order("created_at", { ascending: false })
        .limit(500);
      if (error) throw error;
      return data as unknown as MealRequest[];
    },
  });
}

export function usePatients() {
  return useQuery({
    queryKey: ["patients"],
    queryFn: async () => {
      const { data, error } = await supabase.from("patients").select("*").order("leito");
      if (error) throw error;
      return data as Patient[];
    },
  });
}

export function useAudit(requestId?: string) {
  return useQuery({
    queryKey: ["audit", requestId ?? "all"],
    queryFn: async () => {
      let q = supabase.from("audit_logs").select("*").order("created_at", { ascending: !!requestId }).limit(500);
      if (requestId) q = q.eq("request_id", requestId);
      const { data, error } = await q;
      if (error) throw error;
      return data as AuditLog[];
    },
  });
}

export function useSettings() {
  return useQuery({
    queryKey: ["settings"],
    queryFn: async () => {
      const { data, error } = await supabase.from("app_settings").select("*").eq("id", 1).single();
      if (error) throw error;
      return data;
    },
  });
}

export type TransitionArgs = {
  id: string;
  action: string;
  notes?: string;
  approved_meal?: string;
  request_text?: string;
  success?: string;
};
export function useTransition() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (a: TransitionArgs) => {
      const { error } = await supabase.rpc("transition_request", {
        _id: a.id,
        _action: a.action,
        _notes: a.notes ?? "",
        _approved_meal: a.approved_meal ?? "",
        _request_text: a.request_text ?? "",
      });
      if (error) throw error;
      return a;
    },
    onSuccess: (a) => {
      toast.success(a.success ?? "Ação registrada");
      qc.invalidateQueries({ queryKey: ["requests"] });
      qc.invalidateQueries({ queryKey: ["audit"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });
}
