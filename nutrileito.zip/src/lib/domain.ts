export type Role = "admin" | "enfermagem" | "nutricao" | "cozinha" | "entrega";

export const ROLE_LABEL: Record<Role, string> = {
  admin: "Administrador",
  enfermagem: "Enfermagem",
  nutricao: "Nutrição",
  cozinha: "Cozinha",
  entrega: "Entrega",
};
export const ROLES: Role[] = ["admin", "enfermagem", "nutricao", "cozinha", "entrega"];

export const STATUS = [
  "AGUARDANDO_NUTRICAO",
  "EM_AVALIACAO_NUTRICAO",
  "LIBERADO_PARA_COZINHA",
  "EM_PREPARO",
  "AGUARDANDO_CONFERENCIA_NUTRICAO",
  "DEVOLVIDO_PARA_CORRECAO",
  "LIBERADO_PARA_ENTREGA",
  "AGUARDANDO_TEMPO_MINIMO",
  "ENTREGUE",
  "CANCELADO",
] as const;
export type Status = (typeof STATUS)[number];

export const STATUS_LABEL: Record<Status, string> = {
  AGUARDANDO_NUTRICAO: "Aguardando Nutrição",
  EM_AVALIACAO_NUTRICAO: "Em avaliação",
  LIBERADO_PARA_COZINHA: "Liberado p/ cozinha",
  EM_PREPARO: "Em preparo",
  AGUARDANDO_CONFERENCIA_NUTRICAO: "Aguardando conferência",
  DEVOLVIDO_PARA_CORRECAO: "Devolvido p/ correção",
  LIBERADO_PARA_ENTREGA: "Pronto p/ entrega",
  AGUARDANDO_TEMPO_MINIMO: "Aguardando tempo mínimo",
  ENTREGUE: "Entregue",
  CANCELADO: "Cancelado",
};

export type Tone = "info" | "primary" | "warning" | "success" | "danger" | "muted" | "navy";
export const STATUS_TONE: Record<Status, Tone> = {
  AGUARDANDO_NUTRICAO: "warning",
  EM_AVALIACAO_NUTRICAO: "info",
  LIBERADO_PARA_COZINHA: "primary",
  EM_PREPARO: "primary",
  AGUARDANDO_CONFERENCIA_NUTRICAO: "warning",
  DEVOLVIDO_PARA_CORRECAO: "danger",
  LIBERADO_PARA_ENTREGA: "navy",
  AGUARDANDO_TEMPO_MINIMO: "warning",
  ENTREGUE: "success",
  CANCELADO: "muted",
};

export const MEAL_TYPES = [
  "Café da manhã",
  "Lanche da manhã",
  "Almoço",
  "Lanche da tarde",
  "Jantar",
  "Ceia",
  "Refeição extraordinária",
];

export const RETURNED_TO_LABEL: Record<string, string> = {
  enfermagem: "Enfermagem",
  nutricao: "Nutrição",
  cozinha: "Cozinha",
};

export const LEAD_STATUS = [
  "novo",
  "em_contato",
  "demonstracao_agendada",
  "em_avaliacao",
  "convertido",
  "nao_convertido",
] as const;
export const LEAD_STATUS_LABEL: Record<string, string> = {
  novo: "Novo",
  em_contato: "Em contato",
  demonstracao_agendada: "Demonstração agendada",
  em_avaliacao: "Em avaliação",
  convertido: "Convertido",
  nao_convertido: "Não convertido",
};
export const LEAD_TONE: Record<string, Tone> = {
  novo: "primary",
  em_contato: "info",
  demonstracao_agendada: "warning",
  em_avaliacao: "navy",
  convertido: "success",
  nao_convertido: "muted",
};

export function orderNo(n: number) {
  return "#" + String(n).padStart(6, "0");
}

export function fmtTime(d: string | Date | null | undefined) {
  if (!d) return "—";
  return new Date(d).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
}
export function fmtDateTime(d: string | Date | null | undefined) {
  if (!d) return "—";
  return new Date(d).toLocaleString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}
export function fmtDuration(ms: number) {
  const neg = ms < 0;
  const s = Math.floor(Math.abs(ms) / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = s % 60;
  const out = h > 0 ? `${h}h ${String(m).padStart(2, "0")}min` : `${m}min ${String(ss).padStart(2, "0")}s`;
  return neg ? "-" + out : out;
}

/** Status de exibição: pedidos liberados para entrega antes do tempo mínimo aparecem como AGUARDANDO_TEMPO_MINIMO. */
export function displayStatus(r: { status: string; minimum_delivery_time: string }, now = Date.now()): Status {
  if (r.status === "LIBERADO_PARA_ENTREGA" && new Date(r.minimum_delivery_time).getTime() > now)
    return "AGUARDANDO_TEMPO_MINIMO";
  return r.status as Status;
}

export const ACTIVE_STATUSES = [
  "AGUARDANDO_NUTRICAO",
  "EM_AVALIACAO_NUTRICAO",
  "LIBERADO_PARA_COZINHA",
  "EM_PREPARO",
  "AGUARDANDO_CONFERENCIA_NUTRICAO",
  "DEVOLVIDO_PARA_CORRECAO",
  "LIBERADO_PARA_ENTREGA",
];
